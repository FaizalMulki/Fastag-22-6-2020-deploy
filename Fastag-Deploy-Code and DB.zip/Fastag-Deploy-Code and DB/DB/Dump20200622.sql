CREATE DATABASE  IF NOT EXISTS `fastag` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `fastag`;
-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: fastag
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `document`
--

DROP TABLE IF EXISTS `document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `DocumentName` varchar(1250) DEFAULT NULL,
  `DocumentType` varchar(1250) DEFAULT NULL,
  `Extension` varchar(1250) DEFAULT NULL,
  `DocumentPath` varchar(5545) DEFAULT NULL,
  `Documents` mediumblob,
  `ReferenceId` int DEFAULT NULL,
  `IsVehicle` tinyint DEFAULT NULL,
  `IdType` varchar(400) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `ForeignReference_idx` (`ReferenceId`),
  CONSTRAINT `registration_document_id` FOREIGN KEY (`ReferenceId`) REFERENCES `registration` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document`
--

LOCK TABLES `document` WRITE;
/*!40000 ALTER TABLE `document` DISABLE KEYS */;
/*!40000 ALTER TABLE `document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registration`
--

DROP TABLE IF EXISTS `registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `registration` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL,
  `Email` varchar(145) DEFAULT NULL,
  `Phone` varchar(45) DEFAULT NULL,
  `Mobile` varchar(45) DEFAULT NULL,
  `DeliveryAddress` varchar(1500) DEFAULT NULL,
  `VehicleTypeId` int DEFAULT NULL,
  `VehicleRegNo` varchar(150) DEFAULT NULL,
  `SecurityDeposit` decimal(10,0) DEFAULT NULL,
  `FastagFee` decimal(10,0) DEFAULT NULL,
  `MinimumBalanceDeposit` decimal(10,0) DEFAULT NULL,
  `Others` decimal(10,0) DEFAULT NULL,
  `TotalPayable` decimal(10,0) DEFAULT NULL,
  `IsDeleted` tinyint DEFAULT NULL,
  `CreatedBy` varchar(500) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `ModifiedBy` varchar(500) DEFAULT NULL,
  `ModifiedDate` datetime DEFAULT NULL,
  `ReferenceNumber` varchar(300) DEFAULT NULL,
  `PaymentType` varchar(45) DEFAULT NULL,
  `FromAccountNumber` varchar(45) DEFAULT NULL,
  `ToAccountNumber` varchar(45) DEFAULT NULL,
  `BranchCode` varchar(45) DEFAULT NULL,
  `FatherName` varchar(500) DEFAULT NULL,
  `DOB` datetime DEFAULT NULL,
  `FinacleTransNumber` varchar(255) DEFAULT NULL,
  `StatusId` int DEFAULT NULL,
  `ApprovedBy` varchar(500) DEFAULT NULL,
  `ApproverBranchCode` varchar(50) DEFAULT NULL,
  `ApprovedDate` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `vehicle_registartion_id_idx` (`VehicleTypeId`),
  KEY `status_registration_id_idx` (`StatusId`),
  CONSTRAINT `status_registration_id` FOREIGN KEY (`StatusId`) REFERENCES `status` (`Id`),
  CONSTRAINT `vehicle_registartion_id` FOREIGN KEY (`VehicleTypeId`) REFERENCES `vehicletype` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registration`
--

LOCK TABLES `registration` WRITE;
/*!40000 ALTER TABLE `registration` DISABLE KEYS */;
INSERT  IGNORE INTO `registration` (`Id`, `FirstName`, `LastName`, `Email`, `Phone`, `Mobile`, `DeliveryAddress`, `VehicleTypeId`, `VehicleRegNo`, `SecurityDeposit`, `FastagFee`, `MinimumBalanceDeposit`, `Others`, `TotalPayable`, `IsDeleted`, `CreatedBy`, `CreatedDate`, `ModifiedBy`, `ModifiedDate`, `ReferenceNumber`, `PaymentType`, `FromAccountNumber`, `ToAccountNumber`, `BranchCode`, `FatherName`, `DOB`, `FinacleTransNumber`, `StatusId`, `ApprovedBy`, `ApproverBranchCode`, `ApprovedDate`) VALUES (46,'dsfdsf','dsfsd','fsdf','sdfds','fdsf','dsfsdf',9,'dfds',4,4,4,4,4,0,'admin','2020-06-18 21:20:27','admin','2020-06-18 22:44:57','0001180620201','Transfer','dfds','fdsf',NULL,'dsfsd','2020-06-03 00:00:00','123',2,'admin','001','2020-06-18 22:44:57'),(47,'fdvfd','vfdv','dfvfdv','fdvfd','vfdv','fdvf',7,'fdvfdv',10,10,10,10,10,0,'admin','2020-06-18 21:22:30','admin','2020-06-18 22:45:10','0001180620202','Transfer','fdvfd','vfdv',NULL,'fdvdf',NULL,'123',2,'admin','001','2020-06-18 22:45:10'),(48,'fvfdv','fdvfd','vfd','vfdvf','vfdv','fdvfd',7,'fdvfd',6,6,6,6,6,0,'admin','2020-06-18 21:24:41','admin','2020-06-18 22:45:14','0001180620203','Transfer','dfvfd','vdfvfd',NULL,'fdvdf',NULL,'123',2,'admin','001','2020-06-18 22:45:14'),(49,'dscsd','csdc','sdcds','cdsc','sdcdsc','dscsdc',7,'dcdsc',1,2,5,18,26,0,'admin','2020-06-18 21:25:17','admin','2020-06-18 22:10:06','0001180620204','Transfer','dscsd','dscsdc',NULL,'dscdsc',NULL,'123',2,'admin','001','2020-06-18 22:10:06'),(50,'vdfdsv','dsv','sdvsdv','sdvds','vdsv','dsvsdv',9,'dsvsdv',6,7,8,9,30,0,'admin','2020-06-18 21:28:08','admin','2020-06-18 22:09:59','0001180620205','Transfer','dsvds','dsvsd',NULL,'dsvds','2020-06-15 00:00:00','123',2,'admin','001','2020-06-18 22:09:59'),(51,'esfewf','wefewf','dfsdf@h.com','434534','435435','sadad',7,'sadasd',5,5,6,5,21,0,'admin','2020-06-18 21:34:18','admin','2020-06-18 22:09:51','0001180620206','Transfer','sadasd','sadas',NULL,NULL,NULL,'123',2,'admin','001','2020-06-18 22:09:51'),(52,'xvxv','dfvfd',NULL,NULL,'32432','scsac',9,'sacsa',40,35,16,78,169,0,'admin','2020-06-18 22:30:59','admin','2020-06-19 16:33:25','0001180620207','Transfer','sacas','csac','001',NULL,NULL,'123',2,'admin','001','2020-06-19 16:33:25'),(53,'dcdsc','sdcds',NULL,NULL,'34323423','saxsax',7,'dscdsc',4,4,4,4,16,0,'admin','2020-06-19 12:22:47','admin','2020-06-19 18:02:26','0001190620208','Transfer','dscds','cdscds','001',NULL,NULL,'123',2,'admin','001','2020-06-19 18:02:26'),(54,'dsvds','vdsvsdv',NULL,NULL,'3424324','dsfdsf',7,'sfsfdsf',4,4,4,4,16,0,'admin','2020-06-19 12:31:06','admin','2020-06-19 18:02:18','0001190620209','Transfer','dsvdsv','dsvdsv','001',NULL,NULL,'123',2,'admin','001','2020-06-19 18:02:18'),(55,'dscds','cdsc',NULL,NULL,'32434324','xczxc',7,'xzcxzc',4,4,4,4,16,0,'admin','2020-06-19 12:44:04','admin','2020-06-19 16:33:20','00011906202010','Transfer','xzczx','czxc','001',NULL,NULL,'123',2,'admin','001','2020-06-19 16:33:20'),(56,'dcdsds','fdsf',NULL,NULL,'34232432','zcscdsc',7,'dscdsc',4,4,4,4,16,0,'admin','2020-06-19 13:42:42','admin','2020-06-19 16:29:07','00011906202011','Transfer','dcd','scdsc','001',NULL,NULL,'123',2,'admin','001','2020-06-19 16:29:07'),(57,'vfdfv','fdvfdv',NULL,NULL,'3423423','dscdsc',7,'dcdsc',4,4,4,4,16,0,'admin','2020-06-19 13:45:00','admin','2020-06-19 16:28:59','00011906202012','Transfer','dscds','csdc','001',NULL,NULL,'123',2,'admin','001','2020-06-19 16:28:59'),(58,'ewfewfe','dsfdsfs',NULL,NULL,'324324324','sfsfdsfds',7,'dsfsdfdsf',9,5,16,4,34,0,'admin','2020-06-19 16:39:20','admin','2020-06-19 18:19:40','00011906202013','Transfer','43543','534','001',NULL,NULL,'123',2,'admin','001','2020-06-19 16:41:34');
/*!40000 ALTER TABLE `registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setting`
--

DROP TABLE IF EXISTS `setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `setting` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `VehicleTypeId` int DEFAULT NULL,
  `RefundableSecurityDeposit` decimal(10,0) DEFAULT NULL,
  `FastagFee` decimal(10,0) DEFAULT NULL,
  `MinimumBalanceWalletDeposit` decimal(10,0) DEFAULT NULL,
  `Others` decimal(10,0) DEFAULT NULL,
  `IsDeleted` tinyint DEFAULT '0',
  `CreatedBy` varchar(500) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `ModifiedDate` datetime DEFAULT NULL,
  `ModifiedBy` varchar(500) DEFAULT NULL,
  `EffectiveFrom` datetime DEFAULT NULL,
  `EffectiveTo` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `VehicleTypeReference_idx` (`VehicleTypeId`),
  CONSTRAINT `VehicleTypeReference` FOREIGN KEY (`VehicleTypeId`) REFERENCES `vehicletype` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setting`
--

LOCK TABLES `setting` WRITE;
/*!40000 ALTER TABLE `setting` DISABLE KEYS */;
INSERT  IGNORE INTO `setting` (`Id`, `VehicleTypeId`, `RefundableSecurityDeposit`, `FastagFee`, `MinimumBalanceWalletDeposit`, `Others`, `IsDeleted`, `CreatedBy`, `CreatedDate`, `ModifiedDate`, `ModifiedBy`, `EffectiveFrom`, `EffectiveTo`) VALUES (9,7,4,4,4,4,0,'admin','2020-06-13 13:57:39','2020-06-19 12:21:32','admin','2020-06-04 00:00:00','2020-06-20 00:00:00'),(10,7,5,5,5,5,0,'admin','2020-06-13 14:09:02','2020-06-19 10:37:50','admin','2020-06-21 00:00:00','2020-06-25 00:00:00'),(11,9,4,3,1,7,0,'admin','2020-06-13 14:14:59',NULL,NULL,'2020-06-04 00:00:00','2020-06-16 00:00:00');
/*!40000 ALTER TABLE `setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `status`
--

DROP TABLE IF EXISTS `status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `status` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(75) DEFAULT NULL,
  `Code` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `status`
--

LOCK TABLES `status` WRITE;
/*!40000 ALTER TABLE `status` DISABLE KEYS */;
INSERT  IGNORE INTO `status` (`Id`, `Name`, `Code`) VALUES (1,'Pending','Pending'),(2,'Approved','Approved');
/*!40000 ALTER TABLE `status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehicletype`
--

DROP TABLE IF EXISTS `vehicletype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicletype` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Type` varchar(150) DEFAULT NULL,
  `Code` varchar(150) DEFAULT NULL,
  `IsDeleted` tinyint DEFAULT NULL,
  `CreatedBy` varchar(250) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `ModifiedBy` varchar(250) DEFAULT NULL,
  `ModifiedDate` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicletype`
--

LOCK TABLES `vehicletype` WRITE;
/*!40000 ALTER TABLE `vehicletype` DISABLE KEYS */;
INSERT  IGNORE INTO `vehicletype` (`Id`, `Type`, `Code`, `IsDeleted`, `CreatedBy`, `CreatedDate`, `ModifiedBy`, `ModifiedDate`) VALUES (7,'Car',NULL,0,'admin','2020-06-04 14:36:37',NULL,'0001-01-01 00:00:00'),(8,'Jeep',NULL,1,'admin','2020-06-04 15:38:56',NULL,'0001-01-01 00:00:00'),(9,'Jeep',NULL,0,'admin','2020-06-13 13:32:03','admin','2020-06-19 10:46:48');
/*!40000 ALTER TABLE `vehicletype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'fastag'
--
/*!50003 DROP PROCEDURE IF EXISTS `CheckDataWithinDateRange` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `CheckDataWithinDateRange`(
IN VehicleTypeId INT,
IN EffectiveFrom varchar(200),
IN EffectiveTo varchar(200))
BEGIN
Select * from setting s where s.IsDeleted = 0 and s.VehicleTypeId= VehicleTypeId and (s.EffectiveFrom <= EffectiveFrom and s.EffectiveTo >= EffectiveTo);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllItemsForApproval` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllItemsForApproval`(
IN Search varchar(1000),
IN FromDate varchar(100),
IN ToDate varchar(100),
IN p_iPageIndex INT,    
IN p_iPageSize INT,    
OUT p_iTotalCount  INT  
)
BEGIN
SELECT * FROM(    
SELECT ROW_NUMBER() OVER (ORDER BY ID DESC)  AS RowNumber ,r.*,v.Type as VehicleType,s.Name as StatusName from fastag.registration r
inner join fastag.vehicletype v on v.Id=r.VehicleTypeId
inner join fastag.status s on s.Id=r.StatusId
where r.isdeleted=0 and s.Code='Pending' and date(r.CreatedDate) between FromDate and ToDate
and ( r.FirstName LIKE CONCAT ('%', Search, '%') 
		OR r.LastName LIKE CONCAT ('%', Search, '%') OR r.Email LIKE CONCAT ('%', Search, '%') OR r.Mobile LIKE CONCAT ('%', Search, '%') OR r.ReferenceNumber LIKE CONCAT ('%', Search, '%') OR v.Type LIKE CONCAT ('%', Search, '%') OR r.CreatedBy LIKE CONCAT ('%', Search, '%') OR s.Name LIKE CONCAT ('%', Search, '%')
        or Search is null)


 )     
 A     
 WHERE RowNumber BETWEEN ((p_iPageIndex*p_iPageSize)-p_iPageSize+1) AND (p_iPageIndex*p_iPageSize); 
 
 SET p_iTotalCount = (SELECT COUNT(*)  from  fastag.registration r
inner join fastag.vehicletype v on v.Id=r.VehicleTypeId
inner join fastag.status s on s.Id=r.StatusId
where r.isdeleted=0 and s.Code='Pending' and date(r.CreatedDate) between FromDate and ToDate
 and ( r.FirstName LIKE CONCAT ('%', Search, '%') 
		OR r.LastName LIKE CONCAT ('%', Search, '%') OR r.Email LIKE CONCAT ('%', Search, '%') OR r.Mobile LIKE CONCAT ('%', Search, '%') OR r.ReferenceNumber LIKE CONCAT ('%', Search, '%') OR v.Type LIKE CONCAT ('%', Search, '%') OR r.CreatedBy LIKE CONCAT ('%', Search, '%') OR s.Name LIKE CONCAT ('%', Search, '%')
        or Search is null)
        );
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllItemsForDashBoard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllItemsForDashBoard`(
IN Search varchar(500),
IN FromDate varchar(100),
IN ToDate varchar(100),
IN p_iPageIndex INT,    
IN p_iPageSize INT,    
OUT p_iTotalCount  INT  
)
BEGIN
SELECT * FROM(    
SELECT ROW_NUMBER() OVER (ORDER BY ID DESC)  AS RowNumber ,r.*,v.Type as VehicleType,s.Name as StatusName from fastag.registration r
inner join fastag.vehicletype v on v.Id=r.VehicleTypeId
inner join fastag.status s on s.Id=r.StatusId
where r.isdeleted=0 and date(r.CreatedDate) between FromDate and ToDate
and ( r.FirstName LIKE CONCAT ('%', Search, '%') 
		OR r.LastName LIKE CONCAT ('%', Search, '%') OR r.Email LIKE CONCAT ('%', Search, '%') OR r.Mobile LIKE CONCAT ('%', Search, '%') OR r.ReferenceNumber LIKE CONCAT ('%', Search, '%') OR v.Type LIKE CONCAT ('%', Search, '%') OR r.CreatedBy LIKE CONCAT ('%', Search, '%')  OR s.Name LIKE CONCAT ('%', Search, '%')
        or Search is null)


 )     
 A     
 WHERE RowNumber BETWEEN ((p_iPageIndex*p_iPageSize)-p_iPageSize+1) AND (p_iPageIndex*p_iPageSize); 
 
 SET p_iTotalCount = (SELECT COUNT(*)  from  fastag.registration r
inner join fastag.vehicletype v on v.Id=r.VehicleTypeId
inner join fastag.status s on s.Id=r.StatusId
where r.isdeleted=0 and date(r.CreatedDate) between FromDate and ToDate
 and ( r.FirstName LIKE CONCAT ('%', Search, '%') 
		OR r.LastName LIKE CONCAT ('%', Search, '%') OR r.Email LIKE CONCAT ('%', Search, '%') OR r.Mobile LIKE CONCAT ('%', Search, '%') OR r.ReferenceNumber LIKE CONCAT ('%', Search, '%') OR v.Type LIKE CONCAT ('%', Search, '%') OR r.CreatedBy LIKE CONCAT ('%', Search, '%') OR s.Name LIKE CONCAT ('%', Search, '%')
        or Search is null)
        );
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllRegisterdItems` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllRegisterdItems`(
IN Search varchar(1000),
IN FromDate varchar(100),
IN ToDate varchar(100),
IN p_iPageIndex INT,    
IN p_iPageSize INT,    
OUT p_iTotalCount  INT  
)
BEGIN
SELECT * FROM(    
SELECT ROW_NUMBER() OVER (ORDER BY ID DESC)  AS RowNumber ,r.*,v.Type as VehicleType,s.Name as StatusName from fastag.registration r
inner join fastag.vehicletype v on v.Id=r.VehicleTypeId
inner join fastag.status s on s.Id=r.StatusId
where r.isdeleted=0 and date(r.CreatedDate) between FromDate and ToDate
and ( r.FirstName LIKE CONCAT ('%', Search, '%') 
		OR r.LastName LIKE CONCAT ('%', Search, '%') OR r.Email LIKE CONCAT ('%', Search, '%') OR r.Mobile LIKE CONCAT ('%', Search, '%') OR r.ReferenceNumber LIKE CONCAT ('%', Search, '%') OR v.Type LIKE CONCAT ('%', Search, '%') OR r.CreatedBy LIKE CONCAT ('%', Search, '%')  OR s.Name LIKE CONCAT ('%', Search, '%')
        or Search is null)


 )     
 A     
 WHERE RowNumber BETWEEN ((p_iPageIndex*p_iPageSize)-p_iPageSize+1) AND (p_iPageIndex*p_iPageSize); 
 
 SET p_iTotalCount = (SELECT COUNT(*)  from  fastag.registration r
inner join fastag.vehicletype v on v.Id=r.VehicleTypeId
inner join fastag.status s on s.Id=r.StatusId
where r.isdeleted=0 and date(r.CreatedDate) between FromDate and ToDate
 and ( r.FirstName LIKE CONCAT ('%', Search, '%') 
		OR r.LastName LIKE CONCAT ('%', Search, '%') OR r.Email LIKE CONCAT ('%', Search, '%') OR r.Mobile LIKE CONCAT ('%', Search, '%') OR r.ReferenceNumber LIKE CONCAT ('%', Search, '%') OR v.Type LIKE CONCAT ('%', Search, '%') OR r.CreatedBy LIKE CONCAT ('%', Search, '%') OR s.Name LIKE CONCAT ('%', Search, '%')
        or Search is null)
        );
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllSettings` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllSettings`(
IN Search varchar(1000),
IN p_iPageIndex INT,    
IN p_iPageSize INT,    
OUT p_iTotalCount  INT  

)
BEGIN
SELECT * FROM(    
SELECT ROW_NUMBER() OVER (ORDER BY ID DESC)  AS RowNumber ,s.*,v.Type as VehicleType from fastag.setting s
inner join fastag.vehicletype v on s.VehicleTypeId=v.Id
where s.isdeleted=0 
and (s.RefundableSecurityDeposit LIKE CONCAT ('%', Search, '%')
		OR s.MinimumBalanceWalletDeposit LIKE CONCAT ('%', Search, '%') OR s.Others LIKE CONCAT ('%', Search, '%') OR s.CreatedBy LIKE CONCAT ('%', Search, '%') 
        or Search is null)


 )     
 A     
 WHERE RowNumber BETWEEN ((p_iPageIndex*p_iPageSize)-p_iPageSize+1) AND (p_iPageIndex*p_iPageSize); 
 
 SET p_iTotalCount = (SELECT COUNT(*)  from fastag.setting s where s.isdeleted=0
 and 
		(s.RefundableSecurityDeposit LIKE CONCAT ('%', Search, '%') 	OR s.FastagFee LIKE CONCAT ('%', Search, '%') OR s.MinimumBalanceWalletDeposit LIKE CONCAT ('%', Search, '%') OR s.Others LIKE CONCAT ('%', Search, '%') OR s.CreatedBy LIKE CONCAT ('%', Search, '%') 
        or Search is null)
        );
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetAllVehicles` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetAllVehicles`(
IN Search varchar(1000),
IN p_iPageIndex INT,    
IN p_iPageSize INT,    
OUT p_iTotalCount  INT  )
BEGIN
SELECT * FROM(    
SELECT ROW_NUMBER() OVER (ORDER BY ID DESC)  AS RowNumber ,vt.* from fastag.vehicletype vt
where vt.isdeleted=0 
and ( vt.Type LIKE CONCAT ('%', Search, '%') 
		OR vt.CreatedBy LIKE CONCAT ('%', Search, '%') 
        or Search is null)


 )     
 A     
 WHERE RowNumber BETWEEN ((p_iPageIndex*p_iPageSize)-p_iPageSize+1) AND (p_iPageIndex*p_iPageSize); 
 
 SET p_iTotalCount = (SELECT COUNT(*)  from fastag.vehicletype vt where vt.isdeleted=0
and ( vt.Type LIKE CONCAT ('%', Search, '%') 
		OR vt.CreatedBy LIKE CONCAT ('%', Search, '%') 
        or Search is null)
        );
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetDashBoardCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetDashBoardCount`(
/*IN IsSuperAdmin varchar(150),
IN CreatedBy varchar(250)*/
)
BEGIN
/*IF IsSuperAdmin = 'True' THEN*/
select count(r.Id) As TotalReg,SUM(r.TotalPayable) as TotalAmount from fastag.registration r where r.isdeleted=0;
/*else
select count(statusid) As Total,s.name from notification.messagedetail md  inner join notification.message m on m.Id=md.messageid inner join  notification.status s on s.id = md.statusid where m.isdeleted=0 and  md.isdeleted=0 and m.createdby=CreatedBy or md.createdby=CreatedBy group by statusid;
END If;*/
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GetRegisteredItemById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetRegisteredItemById`(
IN Id INT
)
BEGIN
SELECT r.*,v.Type as VehicleType from fastag.registration r
inner join fastag.vehicletype v on v.Id=r.VehicleTypeId
where  r.Id=Id and r.isdeleted=0 ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-22  9:34:26
