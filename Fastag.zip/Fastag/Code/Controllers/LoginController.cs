﻿using MySql.Data.MySqlClient;
using OrchestratorAsset.Web.DAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Security.Cryptography.X509Certificates;
using System.Web.Configuration;
using System.Web.Hosting;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace OrchestratorAsset.Web.Controllers
{
    [System.Web.Mvc.AllowAnonymous]
    public class LoginController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult LoginAccessDenied()
        {
            return View();
        }

        public ActionResult Login()
        {
            return View();
        }

        public ActionResult HOLogin()
        {
            return View();
        }

        public ActionResult BRLogin()
        {
            return View();
        }


        public ActionResult Logout()
        {
            Response.Cookies["tokenCookie"].Expires = DateTime.Now.AddDays(-1);
            Response.Cookies["Password"].Expires = DateTime.Now.AddDays(-1);
            Response.Cookies["UserId"].Expires = DateTime.Now.AddDays(-1);
            Response.Cookies["IsSuperAdmin"].Expires = DateTime.Now.AddDays(-1);
            Response.Cookies["FullName"].Expires = DateTime.Now.AddDays(-1);
            Session["UserId"] = null;
            Session["Password"] = null;
            Session["FullName"] = null;
            Session["IsSuperAdmin"] = null;
            Session.Clear();
            return RedirectToAction("Login", "Login");
        }


        [HttpPost]
        public ActionResult Login(string EmailID, string Password)
        {
          
            var loginFromAD = ConfigurationManager.AppSettings["ADLoginRequired"];
            if (loginFromAD.ToLower().Trim() == "yes")
            {
                using (PrincipalContext context = new PrincipalContext(ContextType.Domain, ConfigurationManager.AppSettings["ADDomain"].ToString(), EmailID, Password))
                {
                    try
                    {
                        if (!context.ValidateCredentials(EmailID, Password))
                        {
                            Session.Clear();
                            ViewBag.errorMessage = "Please enter valid credentials";
                            return View();
                        }
                        else
                        {
                            var fullName = "";
                            var branchCode = "";
                            Session["IsSuperAdmin"] = false;
                            using (DirectoryEntry entry = UserPrincipal.FindByIdentity(context, EmailID.Trim()).GetUnderlyingObject() as DirectoryEntry)
                            {
                                if (entry != null)
                                {
                                    fullName = entry.Properties["cn"].Value as string;
                                    branchCode = "001";
                                }
                            }

                           

                            string[] superAdmins = ConfigurationManager.AppSettings["SuperAdmin"].ToString().Split(',');
                            foreach (string superUser in superAdmins)
                            {
                                if (superUser == fullName)
                                    Session["IsSuperAdmin"] = true;
                            }

                            Session["FullName"] = fullName;
                            Session["BranchCode"] = branchCode;
                            Session["UserId"] = EmailID.Trim();
                            Session["Password"] = Password;
                            return RedirectToAction("List", "Fastag");
                        }

                    }
                    catch (Exception e)
                    {
                        Session.Clear();
                        ViewBag.errorMessage = e.Message;
                        return View();
                    }
                }
            }
            else
            {
                Session["IsSuperAdmin"] = false;
                string[] superAdmins = ConfigurationManager.AppSettings["SuperAdmin"].ToString().Split(',');
                Session["UserId"] = ConfigurationManager.AppSettings["DummyUserName"];
                var loggedUser = ConfigurationManager.AppSettings["DummyUserName"];
                Session["Password"] = ConfigurationManager.AppSettings["DummyPassword"];
                Session["FullName"] = ConfigurationManager.AppSettings["DummyUserName"];
                Session["BranchCode"] = ConfigurationManager.AppSettings["BranchCode"];
                foreach (string superUser in superAdmins)
                {
                    if (superUser == loggedUser)
                        Session["IsSuperAdmin"] = true;
                }

                Response.Cookies["UserId"].Value = ConfigurationManager.AppSettings["DummyUserName"];
                Response.Cookies["Password"].Value = ConfigurationManager.AppSettings["DummyPassword"];
                Response.Cookies["UserId"].Expires = DateTime.Now.AddHours(1);
                Response.Cookies["Password"].Expires = DateTime.Now.AddHours(1);
                return RedirectToAction("List", "Fastag");
            }

        }




    }


    public class Result
    {
        public string result { get; set; }
    }
}


