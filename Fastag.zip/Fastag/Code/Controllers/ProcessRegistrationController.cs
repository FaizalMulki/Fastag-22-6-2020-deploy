﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OrchestratorAsset.Web.Controllers
{
    public class ProcessRegistrationController : Controller
    {
        // GET: ProcessRegistration
        public ActionResult Index()
        {
            return View();
        }
    }
}